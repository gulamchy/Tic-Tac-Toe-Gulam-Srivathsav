export AWS_SES_SENDER=gulamsulaman@gmail.com
export AWS_REGION=us-east-1
export EMAIL_ADDRESS=sulaman.abir@gmail.com
export EMAIL_ADDRESS=velpurs@wwu.edu
export USER_POOL_ID=us-east-1_DXYZi2A5U
export COGNITO_CLIENT_ID=6mg6g4pjfokaor5jkhdesfnok5
export FUNCTION_ARN=arn:aws:lambda:us-east-1:665687838388:function:tic-tac-toe-api
export BASE_URL=https://q56pua11s5.execute-api.us-east-1.amazonaws.com/prod
